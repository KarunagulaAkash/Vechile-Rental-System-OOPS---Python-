# Car Rental Management System (Python – OOP)

A simple **Car Rental Management System** built with **Python** using **Object-Oriented Programming (OOP)** concepts like *Classes, Inheritance, Encapsulation, and Class Methods*.

## ✨ Features
- Manage vehicles (**Cars** and **Bikes**) with availability
- **Rent** and **Return** vehicles
- **Weekend pricing** logic (extra ₹500 on Saturday/Sunday)
- Track **total rented** and **total returned** vehicles
- Simple in-memory **rental system** (no database needed)

## 🧠 OOP Concepts Used
- `Class` and `Objects`
- `Inheritance` (`Car` and `Bike` inherit from `Vehicle`)
- `Encapsulation` (private attribute `__email` in `Customer`)
- `Class variables` & `@classmethod` (track totals in `Vehicle`)

## 📂 Project Structure
```
Car-Rental-System/
├── car_rental_system.py
├── README.md
└── .gitignore
```

## ▶️ How to Run
1. Install Python 3.8+
2. Run the script:
   ```bash
   python car_rental_system.py
   ```

## 🧪 Example Output (sample)
```
Ram rented vehicle ID C100 cost: 2500
Sita rented vehicle ID B201 cost: 1000
Ramesh rented vehicle ID C102 cost: 2000

== Avaliable Vehicles ==
...

Total Vehicles Rented: 2
Total Vehicles Returned: 2
Estimated cost for 5 days(car2): 10000
```

## 🚀 Future Improvements
- Add CLI menu for user input
- Persist data to a database (SQLite/MySQL)
- Add search/filter by brand, seats, fuel
- Build a simple UI with Streamlit

---

**Author**: LOLABHATTU S S A BHUJANGA RAJU  
**LinkedIn**: https://www.linkedin.com/in/seshu-lolabhattu-019941251/
