class Vehicle():
  total_rented = 0
  total_returned = 0
  def __init__(self,vehicle_id,brand,model,year,rental_rate_per_day,is_available = True):
    self.vehicle_id = vehicle_id
    self.brand = brand
    self.model = model
    self.year = year
    self.rental_rate_per_day = rental_rate_per_day
    self.is_available = is_available

  def display_info(self):
    return (
        f"Vehicle Id: {self.vehicle_id}\n"
        f"Brand: {self.brand}\n"
        f"Model: {self.model}\n"
        f"Year: {self.year}\n"
        f"Rental Rate per day: {self.rental_rate_per_day}\n"
        f"Is Available: {self.is_available}\n"
    )

  def calculate_rent(self,days_type):
      if days_type.lower() in ["saturday","sunday"]:
        return self.rental_rate_per_day + 500
      return self.rental_rate_per_day

  def rent_vehicle(self):
    if self.is_available:
      self.is_available = False
      Vehicle.total_rented += 1
      return "Vehicle has been rented"
    return "Vehicle is not avalible"

  def return_vehicle(self):
    if not self.is_available:
      self.is_available = True
      Vehicle.total_returned += 1
      return "Vehicle is available"
    return "Vehicle is returned successfully"

  def rented_cost(self,days):
    return self.rental_rate_per_day * days

  @classmethod
  def get_total_rented(cls):
    return cls.total_rented

  @classmethod
  def get_total_returned(cls):
    return cls.total_returned


class Car(Vehicle):
  def __init__(self, vehicle_id, brand, model, year, rental_rate_per_day, seats, fuel_type, is_available=True):
    super().__init__(vehicle_id, brand, model, year, rental_rate_per_day, is_available)
    self.seats = seats
    self.fuel_type = fuel_type

  def display_info(self):
    base_info = super().display_info()
    car_info = f"Car Seats: {self.seats}\nFuel Type: {self.fuel_type}"
    return base_info + car_info


class Bike(Vehicle):
  def __init__(self, vehicle_id, brand, model, year, rental_rate_per_day, cc, helmet_required, is_available=True):
    super().__init__(vehicle_id, brand, model, year, rental_rate_per_day, is_available)
    self.cc = cc
    self.helmet_required = helmet_required

  def display_info(self):
    base_info = super().display_info()
    bike_info = f"Engine cc: {self.cc}\nHelmet Required: {self.helmet_required}"
    return base_info + bike_info


class Customer():
  def __init__(self,customer_id,name,email):
    self.customer_id = customer_id
    self.name = name
    self.__email = email
    self.rented_vehicles = []

  def rent_with_days(self,vehicle,days_type = "Weekdays"):
    if vehicle.is_available:
      cost = vehicle.calculate_rent(days_type)
      self.rented_vehicles.append(vehicle)
      vehicle.rent_vehicle()
      return f"{self.name} rented vehicle ID {vehicle.vehicle_id} cost: {cost}"
    return "Vehicle is not avalible"

  def return_vehicle(self,vehicle_id):
    for v in self.rented_vehicles:
      if v.vehicle_id == vehicle_id:
        v.return_vehicle()
        self.rented_vehicles.remove(v)
        return f"{self.name} returned vehicle ID {vehicle_id}"
    return "Vehicle is removed from rented list"

  def get_email(self):
    return self.__email

  def set_email(self,new_email):
    self.__email = new_email

class RentalSystem():
  def __init__(self):
    self.vehicle = []
    self.customer = []

  def add_vehicle(self,vehicle):
    self.vehicle.append(vehicle)
    print(f"Vehicle ID {vehicle.vehicle_id} added.")

  def add_customer(self,customer):
    self.customer.append(customer)
    print(f"Customer ID {customer.customer_id} added.")

  def search_available_vehicle(self):
    return [v for v in self.vehicle if v.is_available]

  def show_rented_vehicles(self):
    return [v for v in self.vehicle if not v.is_available]

if __name__ == "__main__":
  system = RentalSystem()

  car1 = Car("C100", "Toyota", "Innova", 2021, 2000, 7, "Diesel")
  car2 = Car("C101", "Hyundai", "Creta", 2022, 2000, 5, "Petrol")
  car3 = Car("C102", "Toyota", "Innova", 2021, 2000, 7, "Diesel")
  car4 = Car("C103", "Maruti", "Baleno", 2023, 1800, 5, "Petrol")

  bike1 = Bike("B201", "Honda", "Unicorn", 2020, 500, 150, True)
  bike2 = Bike("B201", "Yamaha", "FZ", 2020, 500, 150, True)
  bike3 = Bike("B202", "Honda", "Activa", 2021, 400, 110, True)
  bike4 = Bike("B203", "RoyalEnf", "Classic", 2023, 900, 350, True)

  for v in [car1,car2,car3,car4,bike1,bike2,bike3,bike4]:
    system.add_vehicle(v)

  cust1 = Customer("CU001", "Ram", "ram@example.com")
  cust2 = Customer("CU002", "Sita", "site@example.com")
  cust3 = Customer("CU003", "Ramesh", "ramesh@example.com")

  for c in [cust1,cust2,cust3]:
    system.add_customer(c)

  print(cust1.rent_with_days(car1, "saturday"))
  print(cust2.rent_with_days(bike1, "sunday"))
  print(cust3.rent_with_days(car3, "weekday"))

  print(cust1.return_vehicle("C100"))
  print(cust2.return_vehicle("B201"))

  print("\n== Avaliable Vehicles ==")
  for v in system.search_available_vehicle():
    print(v.display_info(), "\n")

  print("\n== Rented Vehicles ==")
  for v in system.show_rented_vehicles():
    print(v.display_info(), "\n")

  print(f"Total Vehicles Rented: {Vehicle.get_total_rented()}")
  print(f"Total Vehicles Returned: {Vehicle.get_total_returned()}")

  print(f"Estimated cost for 5 days(car2): {car2.rented_cost(5)}")

  print("\n== Car Info == ")
  print(car1.display_info())

  print("\n== Bike Info ==")
  print(bike1.display_info())

  print(f"\nCustomer Mail_Id: {Customer.get_email(cust1)}")
